#ifndef _ONENET_H_
#define _ONENET_H_





void OneNet_SendData(void);
void OneNet_GetData(void);
void OneNet_RevPro(unsigned char *dataPtr);

#endif
